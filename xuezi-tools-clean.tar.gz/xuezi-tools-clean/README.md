# 统一记忆系统 + 自我进化系统 + 知识库管理

**版本**: v2.0  
**作者**: OpenClaw Community  
**适用**: OpenClaw 智能助手框架

---

## 📦 包含内容

### 1. 统一记忆系统 (Unified Memory System)
全生命周期记忆管理解决方案。

**核心功能**:
- ✅ 自动归档系统 - 记忆自动分级归档
- ✅ 重要性评估 - 智能计算记忆重要性
- ✅ 语义搜索 - 快速检索记忆 (<3ms)
- ✅ 用户画像 - 自动分析用户偏好
- ✅ 知识图谱 - 构建实体关系网络
- ✅ 智能推荐 - 个性化内容推荐
- ✅ 技能包记忆 - 追踪技能使用情况
- ✅ 知识库联动 - 记忆与知识库双向同步
- ✅ 决策支持 - 历史决策分析与建议

### 2. 自我进化系统 (Self Evolution System)
持续自我改进和学习系统。

**核心功能**:
- ✅ 学习点自动提取 - 从记忆提取经验教训
- ✅ 改进措施跟踪 - 系统化改进管理
- ✅ 效果评估 - 评估改进措施效果
- ✅ 进化指数 - 量化自我进化程度

### 3. 知识库管理 (Knowledge Base Management)
智能知识库维护系统。

**核心功能**:
- ✅ 文档质量评估
- ✅ 记忆与知识自动关联
- ✅ 过期内容识别
- ✅ 自动生成知识文档

---

## 🚀 快速开始

### 安装要求
- Python 3.8+
- OpenClaw 框架
- macOS/Linux 环境

### 安装步骤

```bash
# 1. 复制到 OpenClaw 技能目录
cp -r unified-memory ~/.openclaw/workspace/skills/
cp -r self-improvement ~/.openclaw/workspace/skills/
cp knowledge-base/kb_manager_v2.py ~/.openclaw/workspace/knowledge-base/

# 2. 设置权限
chmod +x ~/.openclaw/workspace/skills/unified-memory/*.py
chmod +x ~/.openclaw/workspace/skills/self-improvement/*.py

# 3. 创建必要目录
mkdir -p ~/.openclaw/workspace/memory/{archive,permanent,index,knowledge_graph,evolution}
mkdir -p ~/.openclaw/workspace/knowledge-base/{projects,decisions,references}

# 4. 配置定时任务（可选）
bash ~/.openclaw/workspace/skills/unified-memory/scripts/setup-cron.sh
```

---

## ⚙️ 配置说明

### 路径配置
编辑各脚本中的路径变量：
- `MEMORY_DIR` - 记忆文件目录
- `KNOWLEDGE_DIR` - 知识库目录
- `SKILLS_DIR` - 技能包目录

### 个性化配置
在 `user_profile.py` 中配置：
- 你的名称
- 时区设置
- 股票关注列表
- 项目偏好

---

## 📖 使用方法

### 统一记忆系统
```bash
# 运行完整系统
cd ~/.openclaw/workspace/skills/unified-memory
python3 auto_archive.py          # 自动归档
python3 importance_scorer.py     # 重要性评估
python3 semantic_search.py       # 语义搜索
python3 user_profile.py          # 用户画像
python3 knowledge_graph.py       # 知识图谱
python3 smart_recommendation.py  # 智能推荐
```

### 自我进化系统
```bash
cd ~/.openclaw/workspace/skills/self-improvement
python3 evolution_system_v2.py   # 运行自我进化
```

### 知识库管理
```bash
cd ~/.openclaw/workspace/knowledge-base
python3 kb_manager_v2.py         # 知识库管理
```

---

## 🕐 定时任务

推荐配置（每天凌晨1点执行）：

```cron
0 1 * * * ~/.openclaw/workspace/skills/unified-memory/cron_tasks.sh
```

这将自动运行全部11个任务：
1. 自动归档
2. 重要性评估
3. 语义搜索
4. 用户画像更新
5. 知识图谱构建
6. 智能推荐生成
7. 技能包记忆更新
8. 知识库联动
9. 决策支持分析
10. 自我进化系统
11. 知识库管理

---

## 🔒 隐私说明

此版本已移除所有个人隐私信息：
- ✅ 用户名已替换为占位符
- ✅ 服务器信息已替换为占位符
- ✅ 文件路径已标准化
- ✅ 个人ID已替换为占位符

使用前请根据你的环境配置相关参数。

---

## 📄 许可

MIT License - 自由使用和修改

---

## 🙏 致谢

感谢 OpenClaw 社区和所有贡献者。
