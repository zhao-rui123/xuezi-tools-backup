/** 全国31省分时电价数据 */

export type PriceType = '尖峰' | '高峰' | '平段' | '低谷' | '深谷';

export interface TimeSlot {
  type: PriceType;
  startTime: string;
  endTime: string;
  description: string;
}

export interface MonthData {
  monthName: string;
  timeSlots: TimeSlot[];
}

export interface ProvinceData {
  name: string;
  hasTimeOfUsePricing: boolean;
  note?: string;
  months: Record<number, MonthData>;
}

// 电价相对比例（用于图表展示）
export const PRICE_RATIOS: Record<PriceType, number> = {
  '尖峰': 1.8,
  '高峰': 1.5,
  '平段': 1.0,
  '低谷': 0.5,
  '深谷': 0.3
};

// 电价类型颜色
export const PRICE_COLORS: Record<PriceType, string> = {
  '尖峰': '#ef4444',  // 红色
  '高峰': '#f97316',  // 橙色
  '平段': '#22c55e',  // 绿色
  '低谷': '#3b82f6',  // 蓝色
  '深谷': '#6366f1'   // 紫色
};

// 31省电价数据
export const provinceData: ProvinceData[] = [
  {
    name: '河南省',
    hasTimeOfUsePricing: true,
    note: '尖峰：1月、12月17:00-19:00；7-8月20:00-23:00',
    months: {
      1: {
        monthName: '1月',
        timeSlots: [
          { type: '尖峰', startTime: '17:00', endTime: '19:00', description: '尖峰时段' },
          { type: '高峰', startTime: '16:00', endTime: '17:00', description: '高峰时段1' },
          { type: '高峰', startTime: '19:00', endTime: '24:00', description: '高峰时段2' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      2: {
        monthName: '2月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      3: {
        monthName: '3月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      4: {
        monthName: '4月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      5: {
        monthName: '5月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      6: {
        monthName: '6月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      7: {
        monthName: '7月',
        timeSlots: [
          { type: '尖峰', startTime: '20:00', endTime: '23:00', description: '尖峰时段' },
          { type: '高峰', startTime: '16:00', endTime: '20:00', description: '高峰时段1' },
          { type: '高峰', startTime: '23:00', endTime: '24:00', description: '高峰时段2' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      8: {
        monthName: '8月',
        timeSlots: [
          { type: '尖峰', startTime: '20:00', endTime: '23:00', description: '尖峰时段' },
          { type: '高峰', startTime: '16:00', endTime: '20:00', description: '高峰时段1' },
          { type: '高峰', startTime: '23:00', endTime: '24:00', description: '高峰时段2' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      9: {
        monthName: '9月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      10: {
        monthName: '10月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      11: {
        monthName: '11月',
        timeSlots: [
          { type: '高峰', startTime: '16:00', endTime: '24:00', description: '高峰时段' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      12: {
        monthName: '12月',
        timeSlots: [
          { type: '尖峰', startTime: '17:00', endTime: '19:00', description: '尖峰时段' },
          { type: '高峰', startTime: '16:00', endTime: '17:00', description: '高峰时段1' },
          { type: '高峰', startTime: '19:00', endTime: '24:00', description: '高峰时段2' },
          { type: '平段', startTime: '07:00', endTime: '16:00', description: '平段' },
          { type: '低谷', startTime: '00:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
    }
  },
  {
    name: '北京市',
    hasTimeOfUsePricing: true,
    note: '夏季(7-8月)和冬季(1月、12月)实行尖峰电价',
    months: {
      1: {
        monthName: '1月',
        timeSlots: [
          { type: '尖峰', startTime: '17:00', endTime: '19:00', description: '尖峰时段' },
          { type: '高峰', startTime: '08:00', endTime: '12:00', description: '高峰上午' },
          { type: '高峰', startTime: '17:00', endTime: '21:00', description: '高峰晚间' },
          { type: '平段', startTime: '12:00', endTime: '17:00', description: '平段下午' },
          { type: '低谷', startTime: '21:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
      7: {
        monthName: '7月',
        timeSlots: [
          { type: '尖峰', startTime: '11:00', endTime: '13:00', description: '尖峰时段1' },
          { type: '尖峰', startTime: '16:00', endTime: '17:00', description: '尖峰时段2' },
          { type: '高峰', startTime: '10:00', endTime: '11:00', description: '高峰上午1' },
          { type: '高峰', startTime: '13:00', endTime: '16:00', description: '高峰下午' },
          { type: '高峰', startTime: '17:00', endTime: '22:00', description: '高峰晚间' },
          { type: '平段', startTime: '07:00', endTime: '10:00', description: '平段上午' },
          { type: '平段', startTime: '22:00', endTime: '23:00', description: '平段晚间' },
          { type: '低谷', startTime: '23:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      8: {
        monthName: '8月',
        timeSlots: [
          { type: '尖峰', startTime: '11:00', endTime: '13:00', description: '尖峰时段1' },
          { type: '尖峰', startTime: '16:00', endTime: '17:00', description: '尖峰时段2' },
          { type: '高峰', startTime: '10:00', endTime: '11:00', description: '高峰上午1' },
          { type: '高峰', startTime: '13:00', endTime: '16:00', description: '高峰下午' },
          { type: '高峰', startTime: '17:00', endTime: '22:00', description: '高峰晚间' },
          { type: '平段', startTime: '07:00', endTime: '10:00', description: '平段上午' },
          { type: '平段', startTime: '22:00', endTime: '23:00', description: '平段晚间' },
          { type: '低谷', startTime: '23:00', endTime: '07:00', description: '低谷时段' },
        ]
      },
      12: {
        monthName: '12月',
        timeSlots: [
          { type: '尖峰', startTime: '17:00', endTime: '19:00', description: '尖峰时段' },
          { type: '高峰', startTime: '08:00', endTime: '12:00', description: '高峰上午' },
          { type: '高峰', startTime: '17:00', endTime: '21:00', description: '高峰晚间' },
          { type: '平段', startTime: '12:00', endTime: '17:00', description: '平段下午' },
          { type: '低谷', startTime: '21:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
    }
  },
  {
    name: '上海市',
    hasTimeOfUsePricing: true,
    note: '夏季(7-9月)实行尖峰电价',
    months: {
      7: {
        monthName: '7月',
        timeSlots: [
          { type: '尖峰', startTime: '12:00', endTime: '14:00', description: '尖峰时段' },
          { type: '高峰', startTime: '08:00', endTime: '12:00', description: '高峰上午' },
          { type: '高峰', startTime: '14:00', endTime: '15:00', description: '高峰下午1' },
          { type: '高峰', startTime: '18:00', endTime: '21:00', description: '高峰晚间' },
          { type: '平段', startTime: '06:00', endTime: '08:00', description: '平段早晨' },
          { type: '平段', startTime: '15:00', endTime: '18:00', description: '平段下午' },
          { type: '平段', startTime: '21:00', endTime: '22:00', description: '平段晚间' },
          { type: '低谷', startTime: '22:00', endTime: '06:00', description: '低谷时段' },
        ]
      },
      8: {
        monthName: '8月',
        timeSlots: [
          { type: '尖峰', startTime: '12:00', endTime: '14:00', description: '尖峰时段' },
          { type: '高峰', startTime: '08:00', endTime: '12:00', description: '高峰上午' },
          { type: '高峰', startTime: '14:00', endTime: '15:00', description: '高峰下午1' },
          { type: '高峰', startTime: '18:00', endTime: '21:00', description: '高峰晚间' },
          { type: '平段', startTime: '06:00', endTime: '08:00', description: '平段早晨' },
          { type: '平段', startTime: '15:00', endTime: '18:00', description: '平段下午' },
          { type: '平段', startTime: '21:00', endTime: '22:00', description: '平段晚间' },
          { type: '低谷', startTime: '22:00', endTime: '06:00', description: '低谷时段' },
        ]
      },
      9: {
        monthName: '9月',
        timeSlots: [
          { type: '尖峰', startTime: '12:00', endTime: '14:00', description: '尖峰时段' },
          { type: '高峰', startTime: '08:00', endTime: '12:00', description: '高峰上午' },
          { type: '高峰', startTime: '14:00', endTime: '15:00', description: '高峰下午1' },
          { type: '高峰', startTime: '18:00', endTime: '21:00', description: '高峰晚间' },
          { type: '平段', startTime: '06:00', endTime: '08:00', description: '平段早晨' },
          { type: '平段', startTime: '15:00', endTime: '18:00', description: '平段下午' },
          { type: '平段', startTime: '21:00', endTime: '22:00', description: '平段晚间' },
          { type: '低谷', startTime: '22:00', endTime: '06:00', description: '低谷时段' },
        ]
      },
    }
  },
  {
    name: '广东省（珠三角五市）',
    hasTimeOfUsePricing: true,
    note: '广州、深圳、珠海、佛山、东莞执行此电价',
    months: {
      7: {
        monthName: '7月',
        timeSlots: [
          { type: '尖峰', startTime: '11:00', endTime: '12:00', description: '尖峰时段1' },
          { type: '尖峰', startTime: '15:00', endTime: '17:00', description: '尖峰时段2' },
          { type: '高峰', startTime: '10:00', endTime: '11:00', description: '高峰上午' },
          { type: '高峰', startTime: '14:00', endTime: '19:00', description: '高峰下午' },
          { type: '平段', startTime: '08:00', endTime: '10:00', description: '平段上午' },
          { type: '平段', startTime: '12:00', endTime: '14:00', description: '平段中午' },
          { type: '平段', startTime: '19:00', endTime: '24:00', description: '平段晚间' },
          { type: '低谷', startTime: '00:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
    }
  },
  {
    name: '山东省',
    hasTimeOfUsePricing: true,
    note: '深谷电价：5-8月10:00-15:00',
    months: {
      5: {
        monthName: '5月',
        timeSlots: [
          { type: '深谷', startTime: '10:00', endTime: '15:00', description: '深谷时段' },
          { type: '高峰', startTime: '08:00', endTime: '10:00', description: '高峰上午' },
          { type: '高峰', startTime: '15:00', endTime: '22:00', description: '高峰下午晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
      6: {
        monthName: '6月',
        timeSlots: [
          { type: '深谷', startTime: '10:00', endTime: '15:00', description: '深谷时段' },
          { type: '高峰', startTime: '08:00', endTime: '10:00', description: '高峰上午' },
          { type: '高峰', startTime: '15:00', endTime: '22:00', description: '高峰下午晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
      7: {
        monthName: '7月',
        timeSlots: [
          { type: '深谷', startTime: '10:00', endTime: '15:00', description: '深谷时段' },
          { type: '高峰', startTime: '08:00', endTime: '10:00', description: '高峰上午' },
          { type: '高峰', startTime: '15:00', endTime: '22:00', description: '高峰下午晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
      8: {
        monthName: '8月',
        timeSlots: [
          { type: '深谷', startTime: '10:00', endTime: '15:00', description: '深谷时段' },
          { type: '高峰', startTime: '08:00', endTime: '10:00', description: '高峰上午' },
          { type: '高峰', startTime: '15:00', endTime: '22:00', description: '高峰下午晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
    }
  },
  {
    name: '浙江省',
    hasTimeOfUsePricing: true,
    note: '大工业用电执行分时电价',
    months: {
      1: {
        monthName: '1月',
        timeSlots: [
          { type: '尖峰', startTime: '09:00', endTime: '11:00', description: '尖峰时段1' },
          { type: '尖峰', startTime: '13:00', endTime: '17:00', description: '尖峰时段2' },
          { type: '高峰', startTime: '08:00', endTime: '09:00', description: '高峰上午' },
          { type: '高峰', startTime: '11:00', endTime: '13:00', description: '高峰中午' },
          { type: '高峰', startTime: '17:00', endTime: '22:00', description: '高峰晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
      7: {
        monthName: '7月',
        timeSlots: [
          { type: '尖峰', startTime: '09:00', endTime: '11:00', description: '尖峰时段1' },
          { type: '尖峰', startTime: '13:00', endTime: '17:00', description: '尖峰时段2' },
          { type: '高峰', startTime: '08:00', endTime: '09:00', description: '高峰上午' },
          { type: '高峰', startTime: '11:00', endTime: '13:00', description: '高峰中午' },
          { type: '高峰', startTime: '17:00', endTime: '22:00', description: '高峰晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
      8: {
        monthName: '8月',
        timeSlots: [
          { type: '尖峰', startTime: '09:00', endTime: '11:00', description: '尖峰时段1' },
          { type: '尖峰', startTime: '13:00', endTime: '17:00', description: '尖峰时段2' },
          { type: '高峰', startTime: '08:00', endTime: '09:00', description: '高峰上午' },
          { type: '高峰', startTime: '11:00', endTime: '13:00', description: '高峰中午' },
          { type: '高峰', startTime: '17:00', endTime: '22:00', description: '高峰晚间' },
          { type: '低谷', startTime: '22:00', endTime: '08:00', description: '低谷时段' },
        ]
      },
    }
  },
  // 其他省份（暂不实行分时电价或数据待补充）
  { name: '天津市', hasTimeOfUsePricing: false, months: {} },
  { name: '河北省', hasTimeOfUsePricing: false, months: {} },
  { name: '山西省', hasTimeOfUsePricing: false, months: {} },
  { name: '内蒙古自治区', hasTimeOfUsePricing: false, months: {} },
  { name: '辽宁省', hasTimeOfUsePricing: false, months: {} },
  { name: '吉林省', hasTimeOfUsePricing: false, months: {} },
  { name: '黑龙江省', hasTimeOfUsePricing: false, months: {} },
  { name: '江苏省', hasTimeOfUsePricing: false, months: {} },
  { name: '安徽省', hasTimeOfUsePricing: false, months: {} },
  { name: '福建省', hasTimeOfUsePricing: false, months: {} },
  { name: '江西省', hasTimeOfUsePricing: false, months: {} },
  { name: '湖北省', hasTimeOfUsePricing: false, months: {} },
  { name: '湖南省', hasTimeOfUsePricing: false, months: {} },
  { name: '广西壮族自治区', hasTimeOfUsePricing: false, months: {} },
  { name: '海南省', hasTimeOfUsePricing: false, months: {} },
  { name: '重庆市', hasTimeOfUsePricing: false, months: {} },
  { name: '四川省', hasTimeOfUsePricing: false, months: {} },
  { name: '贵州省', hasTimeOfUsePricing: false, months: {} },
  { name: '云南省', hasTimeOfUsePricing: false, months: {} },
  { name: '西藏自治区', hasTimeOfUsePricing: false, months: {} },
  { name: '陕西省', hasTimeOfUsePricing: false, months: {} },
  { name: '甘肃省', hasTimeOfUsePricing: false, months: {} },
  { name: '青海省', hasTimeOfUsePricing: false, months: {} },
  { name: '宁夏回族自治区', hasTimeOfUsePricing: false, months: {} },
  { name: '新疆维吾尔自治区', hasTimeOfUsePricing: false, months: {} },
];

// 辅助函数：获取省份数据
export function getProvinceByName(name: string): ProvinceData | undefined {
  return provinceData.find(p => p.name === name);
}

// 辅助函数：获取省份列表（用于搜索）
export function searchProvinces(term: string): ProvinceData[] {
  return provinceData.filter(p => p.name.toLowerCase().includes(term.toLowerCase()));
}

// 辅助函数：获取有分时电价的省份
export function getProvincesWithTimeOfUsePricing(): ProvinceData[] {
  return provinceData.filter(p => p.hasTimeOfUsePricing);
}
