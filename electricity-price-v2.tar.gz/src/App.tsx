import { useState, useMemo } from 'react';
import { 
  provinceData, 
  PRICE_RATIOS, 
  PRICE_COLORS, 
  type PriceType, 
  type ProvinceData 
} from './data/electricityPriceData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  CartesianGrid
} from 'recharts';
import './App.css';

// 图表数据类型
interface ChartDataItem {
  name: string;
  type: PriceType;
  value: number;
  startTime: string;
  endTime: string;
  color: string;
}

function App() {
  // 默认选择第一个有分时电价的省份
  const defaultProvince = useMemo(() => 
    provinceData.find(p => p.hasTimeOfUsePricing) || provinceData[0],
    []
  );
  
  const [selectedProvince, setSelectedProvince] = useState<ProvinceData>(defaultProvince);
  const [selectedMonth, setSelectedMonth] = useState<number>(1);
  const [searchTerm, setSearchTerm] = useState('');

  // 过滤省份列表
  const filteredProvinces = useMemo(() => {
    if (!searchTerm) return provinceData;
    return provinceData.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [searchTerm]);

  // 获取当前选中月份的电价数据
  const monthData = useMemo(() => {
    if (!selectedProvince.hasTimeOfUsePricing) return null;
    return selectedProvince.months[selectedMonth] || null;
  }, [selectedProvince, selectedMonth]);

  // 生成图表数据
  const chartData: ChartDataItem[] = useMemo(() => {
    if (!monthData) return [];
    return monthData.timeSlots.map(slot => ({
      name: slot.description || slot.type,
      type: slot.type,
      value: PRICE_RATIOS[slot.type],
      startTime: slot.startTime,
      endTime: slot.endTime,
      color: PRICE_COLORS[slot.type]
    }));
  }, [monthData]);

  // 获取电价类型对应的颜色
  const getPriceColor = (type: PriceType): string => PRICE_COLORS[type];

  // 处理省份选择变化
  const handleProvinceChange = (provinceName: string) => {
    const province = provinceData.find(p => p.name === provinceName);
    if (province) {
      setSelectedProvince(province);
    }
  };

  // 自定义Tooltip组件
  const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: any[] }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as ChartDataItem;
      return (
        <div className="custom-tooltip">
          <p className="tooltip-title">{data.type}</p>
          <p className="tooltip-item">电价比例: {data.value}</p>
          <p className="tooltip-item">时间: {data.startTime} - {data.endTime}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="app">
      <div className="container">
        {/* 页面标题 */}
        <header className="header">
          <h1 className="title">
            <span className="title-icon">⚡</span>
            全国31省分时电价查询
          </h1>
          <p className="subtitle">电网代理购电工商业用户分时电价</p>
        </header>

        {/* 主布局 */}
        <div className="main-layout">
          {/* 左侧选择面板 */}
          <aside className="sidebar">
            <div className="form-group">
              <label htmlFor="searchInput">搜索省份</label>
              <input
                id="searchInput"
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="输入省份名称..."
                className="input"
              />
            </div>

            <div className="form-group">
              <label htmlFor="provinceSelect">选择省份</label>
              <select
                id="provinceSelect"
                value={selectedProvince.name}
                onChange={(e) => handleProvinceChange(e.target.value)}
                className="select"
              >
                {filteredProvinces.map(p => (
                  <option key={p.name} value={p.name}>
                    {p.name} {p.hasTimeOfUsePricing ? '' : '(无分时)'}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="monthSelect">选择月份</label>
              <select
                id="monthSelect"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="select"
              >
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>{i + 1}月</option>
                ))}
              </select>
            </div>

            {/* 省份备注信息 */}
            {selectedProvince.note && (
              <div className="note-box">
                <span className="note-icon">📌</span>
                {selectedProvince.note}
              </div>
            )}

            {/* 电价类型图例 */}
            <div className="legend">
              <h3 className="legend-title">电价类型</h3>
              <div className="legend-items">
                {(Object.keys(PRICE_COLORS) as PriceType[]).map(type => (
                  <div key={type} className="legend-item">
                    <span 
                      className="legend-color" 
                      style={{ backgroundColor: PRICE_COLORS[type] }}
                    />
                    <span className="legend-label">{type}</span>
                    <span className="legend-ratio">{PRICE_RATIOS[type]}x</span>
                  </div>
                ))}
              </div>
            </div>
          </aside>

          {/* 右侧内容区 */}
          <main className="content">
            {/* 无分时电价提示 */}
            {!selectedProvince.hasTimeOfUsePricing ? (
              <div className="no-pricing-card">
                <div className="no-pricing-icon">🏠</div>
                <h2>{selectedProvince.name}</h2>
                <p>该省份不实行分时电价政策</p>
              </div>
            ) : monthData ? (
              <>
                {/* 图表区域 */}
                <div className="chart-card">
                  <h2 className="chart-title">
                    {selectedProvince.name} - {selectedMonth}月分时电价
                  </h2>
                  <div className="chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        data={chartData} 
                        margin={{ top: 20, right: 30, left: 20, bottom: 80 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis 
                          dataKey="name" 
                          tick={{ fill: '#94a3b8', fontSize: 11 }}
                          angle={-45}
                          textAnchor="end"
                          height={80}
                          interval={0}
                        />
                        <YAxis 
                          tick={{ fill: '#94a3b8' }}
                          label={{ 
                            value: '电价相对比例', 
                            angle: -90, 
                            position: 'insideLeft', 
                            fill: '#94a3b8',
                            fontSize: 12
                          }}
                          domain={[0, 2]}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* 时段详情卡片 */}
                <div className="time-slots-grid">
                  {monthData.timeSlots.map((slot, idx) => (
                    <div
                      key={idx}
                      className="time-slot-card"
                      style={{ borderLeftColor: getPriceColor(slot.type) }}
                    >
                      <div className="time-slot-header">
                        <span 
                          className="time-slot-type"
                          style={{ color: getPriceColor(slot.type) }}
                        >
                          {slot.type}
                        </span>
                        <span className="time-slot-time">
                          {slot.startTime} - {slot.endTime}
                        </span>
                      </div>
                      <div className="time-slot-desc">
                        {slot.description}
                      </div>
                      <div className="time-slot-ratio">
                        电价比例: {PRICE_RATIOS[slot.type]}x
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              /* 无数据提示 */
              <div className="no-data">
                该月份暂无数据
              </div>
            )}
          </main>
        </div>

        {/* 页脚 */}
        <footer className="footer">
          <p>数据时间：2026年2月 | 执行范围：电网代理购电工商业用户</p>
          <p className="footer-note">
            电价类型（从高到低）：尖峰 > 高峰 > 平段 > 低谷 > 深谷
          </p>
        </footer>
      </div>
    </div>
  );
}

export default App;
