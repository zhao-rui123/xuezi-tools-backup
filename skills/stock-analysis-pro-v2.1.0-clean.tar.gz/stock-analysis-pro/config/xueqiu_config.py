"""
雪球API配置 - 模板文件
请根据说明填入你自己的配置
"""

# HTTP请求头（通常不需要修改）
XUEQIU_HEADERS = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    'origin': 'https://xueqiu.com',
    'priority': 'u=1, i',
    'referer': 'https://xueqiu.com/',
    'sec-ch-ua': '"Not:A-Brand";v="99", "Microsoft Edge";v="145", "Chromium";v="145"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',
}

# =============================================================================
# ⚠️ 重要：请填入你自己的雪球Cookie
# =============================================================================
# 获取方法：
# 1. 用浏览器登录 https://xueqiu.com
# 2. 按 F12 打开开发者工具 → Network（网络）
# 3. 刷新页面，找到任意一个 quote.json 请求
# 4. 右键该请求 → Copy → Copy as cURL (bash)
# 5. 从curl命令中提取 Cookie 部分，填入下方
# =============================================================================

XUEQIU_COOKIES = {
    # 必填：从浏览器开发者工具复制你的Cookie
    'xq_a_token': '请填入你的xq_a_token',
    'xq_id_token': '请填入你的xq_id_token',
    'xq_is_login': '1',
    
    # 以下可选，建议也填入
    'cookiesu': '',
    'device_id': '',
    'u': '',
}

# =============================================================================
# 飞书配置（可选，用于日报推送）
# =============================================================================
# 如果不使用飞书推送功能，可以留空
# 获取方法：
# 1. 在飞书中给AI助手发一条消息
# 2. 查看收到的消息中的 user_id
# =============================================================================

FEISHU_USER_ID = ""  # 填入你的飞书用户ID，如不需要推送可留空

# 大盘指数代码（通常不需要修改）
MARKET_INDICES = {
    "上证指数": "sh000001",
    "深证成指": "sz399001",
    "创业板指": "sz399006",
}
